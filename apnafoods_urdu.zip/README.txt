
APNAFOODS — Urdu Food Delivery (Static site)
-------------------------------------------

فائلیں:
- index.html    (مین ویب پیج)
- style.css     (سائٹ کے لئے سٹائل)
- script.js     (کارٹ، مینو، اور WhatsApp آرڈر فنکشن)
- README.txt    (یہ ہدایات)

خصوصیات:
- اردو (RTL) انٹرفیس
- کارٹ سسٹم: گاہک آئٹمز شامل کرے، مقدار بدل سکے
- چیک آؤٹ: آرڈر آپ کے WhatsApp نمبر پر جائے گا (رقم: +92 307 8879961)
- سادہ Admin پینل: پاسورڈ 'admin123' (مینو میں آئٹمز شامل کرنے کے لیے)
- تمام ڈیٹا localStorage میں محفوظ ہوتا ہے (کوئی بیک اینڈ نہیں)

ڈیپلائے کرنے کا آسان طریقہ (Vercel یا Netlify):
1) Vercel: https://vercel.com -> سائن اپ کریں -> New Project -> Import -> Upload -> zip فائل اپلوڈ کریں
   یا Netlify: https://app.netlify.com -> New site from Git -> drag & drop the ZIP or publish folder.
2) اپلوڈ کے بعد آپ کی سائٹ فوراً آن لائن ہو جائے گی (مثلاً apnafoods.vercel.app)

استعمال:
- مینو دیکھ کر 'شامل کریں' دبائیں، کارٹ میں آئٹمز ہوں گے، پھر 'آرڈر کریں (WhatsApp)' دبائیں۔
- پہلے 'آرڈر کریں' دبانے سے فرم نمودار ہوگی جس میں نام، فون، اور پتہ لکھیں، پھر دوبارہ 'آرڈر کریں' دبائیں — WhatsApp کھلے گا۔

اگر آپ چاہیں تو میں آپ کے لیے یہ ZIP اپلوڈ کرنے کے بعد Vercel پر step-by-step گائیڈ بھی دوں گا۔
